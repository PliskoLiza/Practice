print('The "factorial" module has been imported')
