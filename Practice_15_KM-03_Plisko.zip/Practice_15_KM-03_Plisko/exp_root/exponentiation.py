def exp2(n):
    return n ** 2


def exp3(n):
    return n ** 3
