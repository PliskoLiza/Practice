from math import pow


def root2(n):
    return n ** 0.5


def root3(n):
    x = abs(n) ** (1/3)
    if n > 0:
        return x
    else:
        return - x
