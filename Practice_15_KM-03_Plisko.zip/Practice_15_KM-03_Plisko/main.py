from factorial.factorial import *
from exp_root.exponentiation import *
from exp_root.root import *
from logarithm.logarithm import *


def getNatural(support_text):
    while True:
        getTempNumber = input(f'Please, input number {support_text}: ')
        try:
            getTempNumber = int(getTempNumber)
        except ValueError:
            print(f'"{getTempNumber}" is not a natural number.')
        else:
            if getTempNumber <= 0:
                print(f'"{getTempNumber}" is not a natural number."')
            else:
                break
    return getTempNumber


def getReal(support_text):
    while True:
        getTempNumber = input(f'Please, input number {support_text}: ')
        try:
            getTempNumber = float(getTempNumber)
        except ValueError:
            print(f'"{getTempNumber}" is not a real number.')
        else:
            break
    return getTempNumber


def getPositiveReal(support_text):
    while True:
        getTempNumber = input(f'Please, input number {support_text}: ')
        try:
            getTempNumber = float(getTempNumber)
        except ValueError:
            print(f'"{getTempNumber}" is not a number')
        else:
            if getTempNumber <= 0:
                print(f'"{getTempNumber}" is not a positive number')
            else:
                break
    return getTempNumber


def getNonNegativeReal(support_text):
    while True:
        getTempNumber = input(f'Please, input number {support_text}: ')
        try:
            getTempNumber = float(getTempNumber)
        except ValueError:
            print(f'"{getTempNumber}" is not a number')
        else:
            if getTempNumber < 0:
                print(f'"{getTempNumber}" is not a positive number')
            else:
                break
    return getTempNumber


def getLogarithmBase(support_text):
    while True:
        getTempNumber = input(f'Please, input number {support_text}: ')
        try:
            getTempNumber = float(getTempNumber)
        except ValueError:
            print(f'"{getTempNumber}" is not a number')
        else:
            if getTempNumber <= 0 or getTempNumber == 1:
                print(f'"{getTempNumber}" cannot be the base of the logarithm')
            else:
                break
    return getTempNumber


def main():
    print('\nPlease, choose function, you want to execute:'
          '\n1) log - finding the logarithm of the positive real number by the positive real number,  not equal to 1, base'
          '\n2) ln - finding the natural logarithm of the number by the base e'
          '\n3) lg - finding the logarithm of the number by the base 10'
          '\n4) factorial - finding the factorial of a natural number'
          '\n5) square root - finding the square root of a positive real number'
          '\n6) cube root - finding the cube root of a real number'
          '\n7) exponentiation to the second degree - exponentiation of a real number to the second degree'
          '\n8) exponentiation to the third degree - exponentiation of a real number to the third degree')

    while True:
        func_num = input('Enter function number: ')
        if func_num == '1':
            res = log(getLogarithmBase('which is the logarithm base'),
                      getPositiveReal('which logarithm you want to get'))
        elif func_num == '2':
            res = ln(getPositiveReal('which natural logarithm you want to get'))
        elif func_num == '3':
            res = lg(getPositiveReal('which decimal logarithm you want to get'))
        elif func_num == '4':
            res = fact(getNatural('which factorial you want to get'))
        elif func_num == '5':
            res = root2(getNonNegativeReal('which square root you want to get'))
        elif func_num == '6':
            res = root3(getReal('which cube root you want to get'))
        elif func_num == '7':
            res = exp2(getReal('which exponentiation to the second degree you want to get'))
        elif func_num == '8':
            res = exp3(getReal('which exponentiation to the third degree you want to get'))
        else:
            print('Error! There`s no function with that number. Please, try again')
            continue
        print('Function executing result is: ' + str(res))
        break

while True:
    if __name__ == '__main__':
        main()
    print('If you want to restart the program, press any key.'
          'If you want to exit, press "n".')
    V = input().lower()
    if V == 'n':
        break
