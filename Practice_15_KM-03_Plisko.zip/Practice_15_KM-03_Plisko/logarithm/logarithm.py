from math import log as _log_function, e as _e


def log(a, b):
    return _log_function(b, a)


def ln(b):
    return _log_function(b, 10)


def lg(b):
    return _log_function(b, _e)
