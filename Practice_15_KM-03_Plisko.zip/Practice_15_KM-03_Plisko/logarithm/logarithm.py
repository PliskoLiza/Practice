def _is_more(a, b, delta=0.0001):
    return a > b - delta


def _is_less(a, b, delta=0.0001):
    return a < b + delta


def log(a, b):
    if b == 1:
        return 0
    elif b > 1:
        dr = 1
    else:
        dr = -1

    rlog = 0
    cv = a ** rlog
    lmc = _is_more(a ** rlog, b)
    while not (_is_more(cv, b) and _is_less(cv, b)):
        if _is_more(cv, b) and not _is_less(cv, b):
            if not lmc:
                dr = dr * 0.5
            rlog = rlog - dr
        elif _is_less(cv, b) and not _is_more(cv, b):
            if lmc:
                dr = dr * 0.5
            rlog = rlog + dr
        cv = a ** rlog

    return rlog


def lg(b):
    return log(10, b)


def ln(b):
    return log(2.718281828459045, b)
