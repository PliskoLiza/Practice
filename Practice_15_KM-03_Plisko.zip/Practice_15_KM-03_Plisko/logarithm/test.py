def not_enough(a,b,step=1, delta=0.0001, answer = 1):
    print(answer, 'not_enought')
    if a ** answer < b - delta:
        answer += step / 2

        return too_much(a,b)
    else:
        return too_much(a,b)

def too_much(a,b,step=1, delta=0.0001, answer = 1):
    print(answer, 'too_much')
    if a ** answer > b + delta:
        answer -= step / 2

        return not_enough(a,b)
    else:
        return not_enough(a,b)



def log(a,b):
    if b == 1:
        return 0

too_much(2,4)
