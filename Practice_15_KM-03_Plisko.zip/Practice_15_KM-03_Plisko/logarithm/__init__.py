print('The "logarithm" module has been imported')
